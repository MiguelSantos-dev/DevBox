from sqlalchemy import Column, Integer, String
from .database import Base

class Project(Base):
    __tablename__ = "projects"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    description = Column(String, nullable=False)
    technologies = Column(String, nullable=True)
    status = Column(String, nullable=False)
    repo_link = Column(String, nullable=True)
