from pydantic import BaseModel

class ProjectBase(BaseModel):
    name: str
    description: str
    technologies: str
    status: str
    repo_link: str | None = None

class ProjectCreate(ProjectBase):
    pass

class ProjectOut(ProjectBase):
    id: int

    class Config:
        orm_mode = True
