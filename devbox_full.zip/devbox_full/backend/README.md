# DevBox

DevBox é um gerenciador de projetos pessoais para desenvolvedores. Desenvolvido com FastAPI, permite criar, listar e gerenciar projetos com informações como nome, descrição, tecnologias, status e link do repositório.

## Como rodar

```bash
uvicorn app.main:app --reload
```

Acesse a documentação automática em: http://127.0.0.1:8000/docs
