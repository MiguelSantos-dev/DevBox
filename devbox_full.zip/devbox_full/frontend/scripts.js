document.getElementById('project-form').addEventListener('submit', async function (e) {
    e.preventDefault();

    const project = {
        name: document.getElementById('name').value,
        description: document.getElementById('description').value,
        technologies: document.getElementById('technologies').value,
        status: document.getElementById('status').value,
        repo_link: document.getElementById('repo_link').value || null
    };

    const response = await fetch('http://localhost:8000/projects', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(project)
    });

    if (response.ok) {
        alert("Projeto cadastrado com sucesso!");
        this.reset();
    } else {
        alert("Erro ao cadastrar projeto.");
    }
});
